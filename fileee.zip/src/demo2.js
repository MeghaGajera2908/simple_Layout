import './App.css';

function Myfunctions() {
  return (
    <div>
      <img className='dining' alt='dinning' src='https://sayajihotels.com/images/hotels/sayaji-rajkot/overview/dining.jpg' />
    </div>
  );
}

export default Myfunctions;
