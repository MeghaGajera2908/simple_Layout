import './App.css';

function Myreact() {
  return (
    <div>
      <img className='banquet' alt='dinning' src='https://sayajihotels.com/images/hotels/sayaji-rajkot/overview/events-meetings.jpg' />
    </div>
  );
}

export default Myreact;
